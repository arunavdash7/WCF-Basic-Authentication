﻿using System;

namespace AuthDavid
{
    public class BasicAuthenticationPasswordValidator
    {
        public static bool ValidateUser(string user, string pwd)
        {
            // TODO: return true if user is valid, false if not
            return (user=="user" && pwd == "password");
        }
    }
}